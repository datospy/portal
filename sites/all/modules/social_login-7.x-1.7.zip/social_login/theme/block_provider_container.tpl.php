<?php

/**
 * @file
 * Container in which the social network icons are displayed.
 */

?>
<div class="social_login" style="margin:20px 0 10px 0">
 <div id="<?php echo filter_xss($containerid); ?>"></div>
</div>
